package com.my.touristAttraction.dto;

public enum UserRole {
    ROLE_USER,
    ROLE_ADMIN, USER,
}
